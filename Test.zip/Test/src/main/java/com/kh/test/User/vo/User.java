package com.kh.test.User.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class User {
private String UserNo;
private String UserId;
private String UserName;
private String UserAge;
}