package com.kh.test.controller.UserController;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;

import com.kh.test.User.Service.UserService;
import com.kh.test.User.vo.User;

@Controller
public class UserController {
@Autowired

private UserService service;

@GetMapping("selectUser")

public String selectUser(String userNo, Model model) {

int no = Integer.parseInt(userNo);

User user = service.selectUser(no);

if(user!=null) {

model.addAttribute("user", user);

return "searchSuccess";

}
return "searchFail";

}

}