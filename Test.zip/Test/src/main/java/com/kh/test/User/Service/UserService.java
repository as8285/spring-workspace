package com.kh.test.User.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.kh.test.SelectUserDAO.UserDAO;

import com.kh.test.User.vo.User;


@Service

public class UserService {

@Autowired

private UserDAO dao;

public User selectUser(int no) {

return dao.selectUser(no);

}

}

